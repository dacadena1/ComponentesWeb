#include <iostream>

int main() {
    std::cout << "¡Hola desde C++!\n";
    return 0;
}
